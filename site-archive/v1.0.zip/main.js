(() => {
  const body = document.body;
  const loader = document.getElementById("page-loader");
  const MIN_LOADER_MS = 1000;

  const getStoredStart = () => {
    try {
      const stored = sessionStorage.getItem("loaderStart");
      const parsed = stored ? Number(stored) : NaN;
      return Number.isFinite(parsed) ? parsed : Date.now();
    } catch (error) {
      return Date.now();
    }
  };

  let loaderStart = getStoredStart();

  const showLoader = () => {
    if (!loader) return;
    loader.classList.add("is-active");
    loader.classList.remove("is-exit");
  };

  const hideLoader = () => {
    if (!loader) return;
    const elapsed = Date.now() - loaderStart;
    const delay = Math.max(0, MIN_LOADER_MS - elapsed);
    setTimeout(() => {
      loader.classList.add("is-exit");
      setTimeout(() => {
        loader.classList.remove("is-active", "is-exit");
        try {
          sessionStorage.removeItem("loaderStart");
        } catch (error) {
          // Ignore storage errors.
        }
      }, 520);
    }, delay);
  };

  if (loader) {
    showLoader();
    window.addEventListener("load", hideLoader, { once: true });
  }

  const quoteTargets = document.querySelectorAll("[data-loader-quote]");
  if (quoteTargets.length) {
    const quotes = [
      "Greed is a bottomless pit which exhausts the person in an endless effort to satisfy the need without ever reaching satisfaction. - Erich Fromm",
      "Earth provides enough to satisfy every man's needs, but not every man's greed. - Mahatma Gandhi",
      "The more you have, the more you know you don't have. - Aristotle Onassis",
      "It is not the man who has too little, but the man who craves more, that is poor. - Seneca",
      "We are in danger of destroying ourselves by our greed and stupidity. - Stephen Hawking",
      "Greed is the lack of confidence of one's own ability to create. - Vanna Bonta",
      "There is no fire like passion, there is no shark like hatred, there is no snare like folly, there is no torrent like greed. - Siddharta Gautama",
      "The greedy search for money or success will almost always lead men into unhappiness. - Andre Maurois",
      "He who is not contented with what he has, would not be contented with what he would like to have. - Socrates",
      "Greed lessens what is gathered. - Arab proverb",
      "There is a sufficiency in the world for people's need but not for people's greed. - Mohandas Gandhi",
      "The avaricious man is like the barren sandy ground of the desert which sucks in all the rain and dew with greediness, but yields no fruitful herbs or plants for the benefit of others. - Zeno",
      "Wealth is like sea-water; the more we drink, the thirstier we become. - Arthur Schopenhauer",
      "Nothing makes us more vulnerable than loneliness, except greed. - Thomas Harris",
      "Hell has three gates: lust, anger, and greed. - Bhagavad Gita"
    ];
    const pick = quotes[Math.floor(Math.random() * quotes.length)];
    quoteTargets.forEach((target) => {
      target.textContent = pick;
    });
  }


  const loaderIcons = document.querySelectorAll("[data-loader-icon]");
  if (loaderIcons.length) {
    const iconPaths = [
      "assets/stars/LOCKPICK.svg",
      "assets/stars/RIFLE.svg",
      "assets/stars/MEDICALTOOLS.svg",
      "assets/stars/SILVERBALLER.svg"
    ];
    loaderIcons.forEach((icon) => {
      const pick = iconPaths[Math.floor(Math.random() * iconPaths.length)];
      icon.src = pick;
    });
  }

  // Page fade-in.
  requestAnimationFrame(() => {
    body.classList.add("page-ready");
  });

  // Smooth page transitions for internal links.
  const isInternalLink = (link) => {
    const href = link.getAttribute("href") || "";
    if (!href || href.startsWith("#")) return false;
    if (link.target === "_blank" || link.hasAttribute("download")) return false;
    if (href.startsWith("http") || href.startsWith("mailto:") || href.startsWith("tel:")) return false;
    return true;
  };

  document.querySelectorAll("a").forEach((link) => {
    if (!isInternalLink(link)) return;
    link.addEventListener("click", (event) => {
      event.preventDefault();
      body.classList.add("page-exit");
      loaderStart = Date.now();
      try {
        sessionStorage.setItem("loaderStart", String(loaderStart));
      } catch (error) {
        // Ignore storage errors.
      }
      showLoader();
      const target = link.getAttribute("href");
      setTimeout(() => {
        window.location.href = target;
      }, 360);
    });
  });

  // Active navigation state.
  const navLinks = document.querySelectorAll("[data-nav]");
  const current = window.location.pathname.split("/").pop() || "index.html";
  navLinks.forEach((link) => {
    if (link.getAttribute("href") === current) {
      link.classList.add("active");
      link.setAttribute("aria-current", "page");
    }
  });

  // Docked navigation when scrolling.
  const header = document.querySelector(".site-header");
  const sideNav = document.querySelector(".side-nav");
  const dockThreshold = 260;
  const updateDock = () => {
    const docked = window.scrollY > dockThreshold;
    header?.classList.toggle("docked", docked);
    body.classList.toggle("nav-docked", docked);
    if (sideNav) {
      sideNav.setAttribute("aria-hidden", docked ? "false" : "true");
    }
  };
  window.addEventListener("scroll", updateDock);
  updateDock();

  // Clock.
  const clockEls = document.querySelectorAll("[data-clock]");
  if (clockEls.length) {
    const formatter = new Intl.DateTimeFormat(undefined, {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: false
    });
    const tick = () => {
      const time = formatter.format(new Date());
      clockEls.forEach((el) => {
        el.textContent = time;
      });
    };
    tick();
    setInterval(tick, 1000);
  }

  // Scroll reveal for blur/fade elements.
  const revealTargets = document.querySelectorAll("[data-reveal], [data-blur-text]");
  if (revealTargets.length) {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach((entry) => {
          if (entry.isIntersecting) {
            entry.target.classList.add("is-visible");
          } else {
            entry.target.classList.remove("is-visible");
          }
        });
      },
      { threshold: 0.35 }
    );
    revealTargets.forEach((target) => observer.observe(target));
  }

  // Gallery modal interactions.
  const modal = document.getElementById("gallery-modal");
  const modalImage = document.getElementById("modal-image");
  const modalClose = document.getElementById("modal-close");
  if (modal && modalImage) {
    const thumbnails = document.querySelectorAll("[data-gallery]");
    thumbnails.forEach((thumb) => {
      thumb.addEventListener("click", () => {
        modalImage.src = thumb.dataset.full;
        modalImage.alt = thumb.dataset.alt || "Gallery preview";
        modal.classList.remove("hidden");
        modal.setAttribute("aria-hidden", "false");
      });
    });

    const closeModal = () => {
      modal.classList.add("hidden");
      modal.setAttribute("aria-hidden", "true");
    };

    modal.addEventListener("click", (event) => {
      if (event.target === modal) closeModal();
    });

    modalClose?.addEventListener("click", closeModal);
    window.addEventListener("keydown", (event) => {
      if (event.key === "Escape") closeModal();
    });
  }

  // Lab demo overlays.
  const demoButtons = document.querySelectorAll("[data-demo-open]");
  if (demoButtons.length) {
    demoButtons.forEach((button) => {
      const targetId = button.getAttribute("data-demo-open");
      const modalEl = targetId ? document.getElementById(targetId) : null;
      button.addEventListener("click", () => {
        if (!modalEl) return;
        modalEl.classList.add("is-active");
        modalEl.setAttribute("aria-hidden", "false");
      });
    });

    document.querySelectorAll("[data-demo-close]").forEach((closeBtn) => {
      closeBtn.addEventListener("click", () => {
        const modalEl = closeBtn.closest(".demo-modal");
        if (!modalEl) return;
        modalEl.classList.remove("is-active");
        modalEl.setAttribute("aria-hidden", "true");
      });
    });
  }

  // Archive listing from local manifest.
  const archiveList = document.getElementById("archive-list");
  const archivePreview = document.getElementById("archive-preview");
  if (archiveList || archivePreview) {
    const formatSize = (bytes) => {
      if (bytes < 1024) return `${bytes} B`;
      const kb = bytes / 1024;
      if (kb < 1024) return `${kb.toFixed(1)} KB`;
      return `${(kb / 1024).toFixed(1)} MB`;
    };

    const buildCard = (entry) => {
      const card = document.createElement("article");
      card.className = "archive-card";

      const title = document.createElement("h3");
      title.textContent = `Version ${entry.version}`;

      const size = document.createElement("p");
      size.className = "muted";
      size.textContent = `File size: ${formatSize(entry.size)}`;

      const download = document.createElement("a");
      download.href = entry.file;
      download.textContent = "Download";
      download.setAttribute("download", "");

      card.appendChild(title);
      card.appendChild(size);
      card.appendChild(download);
      return card;
    };

    const renderAll = (entries) => {
      if (archiveList) {
        archiveList.innerHTML = "";
        if (!entries.length) {
          archiveList.innerHTML = "<p class=\"muted\">No archive entries found.</p>";
        } else {
          entries.forEach((entry) => archiveList.appendChild(buildCard(entry)));
        }
      }

      if (archivePreview) {
        archivePreview.innerHTML = "";
        if (!entries.length) {
          archivePreview.innerHTML = "<p class=\"muted\">No archive entries found.</p>";
        } else {
          archivePreview.appendChild(buildCard(entries[0]));
        }
      }
    };

    const loadFallback = () => {
      const fallback = document.getElementById("archive-fallback");
      if (!fallback) return null;
      try {
        return JSON.parse(fallback.textContent);
      } catch (error) {
        return null;
      }
    };

    fetch("site-archive/manifest.json")
      .then((response) => response.json())
      .then((entries) => renderAll(entries))
      .catch(() => {
        const entries = loadFallback() || [];
        renderAll(entries);
      });
  }
})();
